# MyFacePage2
 

 # Cabeçalho

 O cabeçalho foi a primeira parte desenvolvida no processo, contendo o tema da página que é "Página de apresentação pessoal".

 # Informações 

 As informações inseridas na página são meus dados pessoais para contato, onde eu estudei, meus interesses e minhas qualidades no trabalho. E no final uma foto para identificação.

 # Rodapé

 No fim da página adicionei um rodapé azul escuro que contém meu nome e o ano em que o site foi feito.